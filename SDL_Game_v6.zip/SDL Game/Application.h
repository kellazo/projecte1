#pragma once

#include "p2List.h"
#include "Globals.h"
#include "Module.h"
#include "Dummy.h"
#include "ModuleWindow.h"
#include "ModuleRender.h"
#include "ModuleTextures.h"
#include "ModuleInput.h"
#include "ModuleAudio.h"
#include "ModuleSceneSpace.h"
#include "ModulePlayer.h"
#include "ModuleFadeToBlack.h"
#include "ModuleParticles.h"

class Application
{
public:
	ModuleRender* renderer;
	ModuleWindow* window;
	ModuleTextures* textures;
	ModuleInput* input;
	ModuleAudio* audio;
	// TODO 0: Crear escena de intro:
	// Crear fitxers .h i .cpp
	// Crear la instancia de la classe a Application i afegir-la com modul
	// Fer que el modul intro sigui el primer en executar-se
	// Fer que carregui el fons rtype/intro.png i la musica rtype/intro.ogg
	// Quant s'apreti el espai soni el fx "rtype/starting.wav" que fent un fade vagi a la escena del espai
	ModuleSceneSpace* scene_space;
	ModulePlayer* player;
	ModuleFadeToBlack* fade;
	ModuleParticles* particles;

private:

	p2List<Module*> list_modules;

public:

	Application();
	~Application();

	bool Init();
	update_status Update();
	bool CleanUp();

private:

	void AddModule(Module* mod);
};